const express = require("express");
const app = express();
const port = 3000;
const path = require("path");
const fs = require("node:fs");

app.use(express.json());
app.set("view engine", "ejs");

app.set("views", `${path.resolve(__dirname + "/views")}`);

app.get("/", (req, res) => {
  res.render("index", { value: 0 });
});

app.post("/bmi", (req, res) => {
  let expression = req.body.string;
  try {
    console.log(expression);
    result = eval(expression);
    res.send(JSON.stringify({ result: result }));
  } catch (e) {
    console.error(e);
    res.send(400);
  }
});

app.listen(port, () => {
  console.log(`Server is listening on ${port}`);
});
